<?php
namespace com\kwipped\approve\wordpress\plugin;
//****************************************************************************************
//* You should not modify the code below. It assures the correct format needed by Approve.
//*****************************************************************************************
class OLDApproveWordPressPlugin{
	public static function get_settings(){}
}
?>