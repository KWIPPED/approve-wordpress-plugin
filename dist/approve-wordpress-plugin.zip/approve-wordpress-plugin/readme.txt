EDIT THIS FILE


=== APPROVE Wordpress Plugin ===
Contributors: Wellington Souza
Donate link: N/A
Tags: approve, kwippped, devtools
Requires at least: 4.6
Tested up to: 5.4
Stable tag: 2.0.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Provides KWIPPED APPROVE functionality to Wordpress sites.

== Description ==

The APPROVE WorPress Plugin provides the KWIPPED APPROVE Plugin in WordPress. 
You may follow the APPROVE tag standards and build equipment financing into your site 
with minimum web design effort. Both the embedded and hosted application models are provided.

== Installation ==

Download the plugin from the dist folder at  https://https://github.com/KWIPPED/approve-wordpress-plugin/tree/master/dist.

1. Visit the Plugins page of your Wordpress instance and click on "Add New"
1. Click on "Upload Plugin" and point to the recently downloaded approve-wordpress-plugin.php file

More informatinon on how to integrate it into your Worpress site is available at https://github.com/KWIPPED/approve-wordpress-plugin.

== Frequently Asked Questions ==

Please visit https://github.com/KWIPPED/approve-wordpress-plugin.

== Changelog ==

= 2.0.2 =
* Bug with new approve URL.

= 2.0.2 =
* Fixed bug in settings.

= 2.0.1 =
* The first publically avaialble version.